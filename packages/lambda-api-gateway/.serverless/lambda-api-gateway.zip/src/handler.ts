import { APIGatewayEvent, APIGatewayProxyResult } from 'aws-lambda';

export const mainHandler = async (
  event: APIGatewayEvent,
): Promise<APIGatewayProxyResult> => {
  console.log('Event:', event);
  return {
    statusCode: 200,
    body: JSON.stringify({ message: 'Hello from Lambda API Gateway!' }),
  };
};
